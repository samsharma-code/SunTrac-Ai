import { createBrowserRouter } from "react-router";
import { DashboardLayout } from "./components/DashboardLayout";
import { Overview } from "./components/Overview";
import { Analytics } from "./components/Analytics";
import { Alerts } from "./components/Alerts";
import { Settings } from "./components/Settings";
import { Comparison } from "./components/Comparison";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: DashboardLayout,
    children: [
      { index: true, Component: Overview },
      { path: "analytics", Component: Analytics },
      { path: "comparison", Component: Comparison },
      { path: "alerts", Component: Alerts },
      { path: "settings", Component: Settings },
    ],
  },
]);