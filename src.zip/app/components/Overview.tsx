import { useEffect, useState } from "react";
import { LiveChart } from "./LiveChart";
import { BatteryHealth } from "./BatteryHealth";
import { FaultAlerts } from "./FaultAlerts";
import { WeatherAlerts } from "./WeatherAlerts";
import { StatsCard } from "./StatsCard";
import { Zap, TrendingUp, Gauge, ThermometerSun } from "lucide-react";

interface SolarData {
  voltage: number;
  current: number;
  temperature: number;
  power: number;
}

export function Overview() {
  const [solarData, setSolarData] = useState<SolarData>({
    voltage: 48.5,
    current: 12.3,
    temperature: 35.2,
    power: 596.55,
  });

  const [voltageHistory, setVoltageHistory] = useState<Array<{ time: string; value: number }>>([]);
  const [currentHistory, setCurrentHistory] = useState<Array<{ time: string; value: number }>>([]);
  const [temperatureHistory, setTemperatureHistory] = useState<Array<{ time: string; value: number }>>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString();

      // Generate realistic fluctuations
      const newVoltage = 48 + Math.random() * 4;
      const newCurrent = 10 + Math.random() * 5;
      const newTemperature = 30 + Math.random() * 10;
      const newPower = newVoltage * newCurrent;

      setSolarData({
        voltage: newVoltage,
        current: newCurrent,
        temperature: newTemperature,
        power: newPower,
      });

      setVoltageHistory((prev) => {
        const updated = [...prev, { time: timeStr, value: newVoltage }];
        return updated.slice(-20);
      });

      setCurrentHistory((prev) => {
        const updated = [...prev, { time: timeStr, value: newCurrent }];
        return updated.slice(-20);
      });

      setTemperatureHistory((prev) => {
        const updated = [...prev, { time: timeStr, value: newTemperature }];
        return updated.slice(-20);
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold mb-2">Solar Energy Dashboard</h2>
        <p className="text-gray-400">Real-time monitoring and system status</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Voltage"
          value={`${solarData.voltage.toFixed(2)} V`}
          icon={Gauge}
          trend="+2.3%"
          color="blue"
        />
        <StatsCard
          title="Current"
          value={`${solarData.current.toFixed(2)} A`}
          icon={Zap}
          trend="+5.1%"
          color="yellow"
        />
        <StatsCard
          title="Power Output"
          value={`${solarData.power.toFixed(0)} W`}
          icon={TrendingUp}
          trend="+7.8%"
          color="green"
        />
        <StatsCard
          title="Temperature"
          value={`${solarData.temperature.toFixed(1)} °C`}
          icon={ThermometerSun}
          trend="-1.2%"
          color="red"
        />
      </div>

      {/* Live Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LiveChart
          title="Voltage (V)"
          data={voltageHistory}
          color="#3b82f6"
          unit="V"
        />
        <LiveChart
          title="Current (A)"
          data={currentHistory}
          color="#eab308"
          unit="A"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LiveChart
          title="Temperature (°C)"
          data={temperatureHistory}
          color="#ef4444"
          unit="°C"
        />
        <BatteryHealth />
      </div>

      {/* Alerts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FaultAlerts />
        <WeatherAlerts />
      </div>
    </div>
  );
}
