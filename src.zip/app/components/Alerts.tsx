import { AlertTriangle, AlertCircle, Info, CheckCircle, Clock } from "lucide-react";

const allAlerts = [
  {
    id: "1",
    type: "error" as const,
    title: "Inverter 2 Connection Lost",
    message: "Unable to communicate with inverter 2. Check network connection.",
    timestamp: "5 minutes ago",
    status: "active",
  },
  {
    id: "2",
    type: "warning" as const,
    title: "Panel 3 Efficiency Drop",
    message: "Panel 3 efficiency decreased by 5%. Possible shading or dirt accumulation.",
    timestamp: "15 minutes ago",
    status: "active",
  },
  {
    id: "3",
    type: "warning" as const,
    title: "High Temperature Alert",
    message: "Panel array temperature exceeded 45°C. Performance may be affected.",
    timestamp: "1 hour ago",
    status: "active",
  },
  {
    id: "4",
    type: "info" as const,
    title: "Scheduled Maintenance",
    message: "System maintenance is scheduled for tomorrow at 10:00 AM.",
    timestamp: "2 hours ago",
    status: "pending",
  },
  {
    id: "5",
    type: "success" as const,
    title: "Battery Fully Charged",
    message: "Battery bank has reached 100% capacity.",
    timestamp: "3 hours ago",
    status: "resolved",
  },
  {
    id: "6",
    type: "warning" as const,
    title: "Grid Connection Fluctuation",
    message: "Detected voltage fluctuations in grid connection.",
    timestamp: "4 hours ago",
    status: "resolved",
  },
  {
    id: "7",
    type: "info" as const,
    title: "Firmware Update Available",
    message: "New firmware version 2.4.1 is available for your inverter.",
    timestamp: "1 day ago",
    status: "pending",
  },
  {
    id: "8",
    type: "success" as const,
    title: "Record Production Day",
    message: "Yesterday's energy production reached a new record of 125 kWh.",
    timestamp: "1 day ago",
    status: "resolved",
  },
];

const alertConfig = {
  error: {
    icon: AlertCircle,
    bgColor: "bg-red-500/10",
    borderColor: "border-red-500/30",
    textColor: "text-red-400",
    iconBgColor: "bg-red-500/20",
  },
  warning: {
    icon: AlertTriangle,
    bgColor: "bg-yellow-500/10",
    borderColor: "border-yellow-500/30",
    textColor: "text-yellow-400",
    iconBgColor: "bg-yellow-500/20",
  },
  info: {
    icon: Info,
    bgColor: "bg-blue-500/10",
    borderColor: "border-blue-500/30",
    textColor: "text-blue-400",
    iconBgColor: "bg-blue-500/20",
  },
  success: {
    icon: CheckCircle,
    bgColor: "bg-green-500/10",
    borderColor: "border-green-500/30",
    textColor: "text-green-400",
    iconBgColor: "bg-green-500/20",
  },
};

const statusBadges = {
  active: "bg-red-500/20 text-red-400 border-red-500/30",
  pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  resolved: "bg-green-500/20 text-green-400 border-green-500/30",
};

export function Alerts() {
  const activeAlerts = allAlerts.filter((a) => a.status === "active");
  const pendingAlerts = allAlerts.filter((a) => a.status === "pending");
  const resolvedAlerts = allAlerts.filter((a) => a.status === "resolved");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">System Alerts</h2>
        <p className="text-gray-400">Monitor and manage system notifications</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-900 border border-red-500/30 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Active Alerts</p>
          <p className="text-3xl font-bold text-red-400">{activeAlerts.length}</p>
        </div>
        <div className="bg-gray-900 border border-yellow-500/30 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Pending</p>
          <p className="text-3xl font-bold text-yellow-400">{pendingAlerts.length}</p>
        </div>
        <div className="bg-gray-900 border border-green-500/30 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Resolved Today</p>
          <p className="text-3xl font-bold text-green-400">{resolvedAlerts.length}</p>
        </div>
      </div>

      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold mb-4 text-gray-100">Active Alerts</h3>
          <div className="space-y-3">
            {activeAlerts.map((alert) => {
              const config = alertConfig[alert.type];
              const Icon = config.icon;
              return (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border ${config.bgColor} ${config.borderColor}`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-2 rounded-lg ${config.iconBgColor} flex-shrink-0`}>
                      <Icon size={20} className={config.textColor} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h4 className="font-semibold text-gray-100">{alert.title}</h4>
                        <span
                          className={`px-2 py-1 text-xs rounded-full border ${statusBadges[alert.status]} whitespace-nowrap`}
                        >
                          {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-2">{alert.message}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock size={12} />
                        <span>{alert.timestamp}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Pending Alerts */}
      {pendingAlerts.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold mb-4 text-gray-100">Pending</h3>
          <div className="space-y-3">
            {pendingAlerts.map((alert) => {
              const config = alertConfig[alert.type];
              const Icon = config.icon;
              return (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border ${config.bgColor} ${config.borderColor}`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-2 rounded-lg ${config.iconBgColor} flex-shrink-0`}>
                      <Icon size={20} className={config.textColor} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h4 className="font-semibold text-gray-100">{alert.title}</h4>
                        <span
                          className={`px-2 py-1 text-xs rounded-full border ${statusBadges[alert.status]} whitespace-nowrap`}
                        >
                          {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-2">{alert.message}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock size={12} />
                        <span>{alert.timestamp}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Resolved Alerts */}
      {resolvedAlerts.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold mb-4 text-gray-100">Recently Resolved</h3>
          <div className="space-y-3">
            {resolvedAlerts.map((alert) => {
              const config = alertConfig[alert.type];
              const Icon = config.icon;
              return (
                <div
                  key={alert.id}
                  className="p-4 rounded-lg border bg-gray-900 border-gray-800 opacity-70"
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-2 rounded-lg ${config.iconBgColor} flex-shrink-0`}>
                      <Icon size={20} className={config.textColor} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h4 className="font-semibold text-gray-100">{alert.title}</h4>
                        <span
                          className={`px-2 py-1 text-xs rounded-full border ${statusBadges[alert.status]} whitespace-nowrap`}
                        >
                          {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-2">{alert.message}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock size={12} />
                        <span>{alert.timestamp}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
