import { Outlet, NavLink } from "react-router";
import { Sun, BarChart3, AlertTriangle, Settings, Menu, X, TrendingUp } from "lucide-react";
import { useState } from "react";

export function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    { to: "/", label: "Overview", icon: Sun },
    { to: "/analytics", label: "Analytics", icon: BarChart3 },
    { to: "/comparison", label: "Comparison", icon: TrendingUp },
    { to: "/alerts", label: "Alerts", icon: AlertTriangle },
    { to: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Mobile Menu Button */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors"
      >
        {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-gray-900 border-r border-gray-800 transition-transform duration-300 z-40 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
      >
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 bg-yellow-500 rounded-lg">
              <Sun className="w-6 h-6 text-gray-900" />
            </div>
            <div>
              <h1 className="font-bold text-xl">Solar Monitor</h1>
              <p className="text-xs text-gray-400">Energy Dashboard</p>
            </div>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive
                      ? "bg-yellow-500 text-gray-900"
                      : "text-gray-400 hover:bg-gray-800 hover:text-gray-100"
                  }`
                }
              >
                <item.icon size={20} />
                <span>{item.label}</span>
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-gray-800">
          <div className="text-xs text-gray-500">
            <p>System Status: Online</p>
            <p className="mt-1">Last Update: Just now</p>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="lg:ml-64 min-h-screen p-4 md:p-8">
        <Outlet />
      </main>
    </div>
  );
}