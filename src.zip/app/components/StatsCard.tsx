import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trend: string;
  color: "blue" | "yellow" | "green" | "red";
}

const colorClasses = {
  blue: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  yellow: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  green: "bg-green-500/10 text-green-400 border-green-500/20",
  red: "bg-red-500/10 text-red-400 border-red-500/20",
};

const iconColorClasses = {
  blue: "bg-blue-500/20 text-blue-400",
  yellow: "bg-yellow-500/20 text-yellow-400",
  green: "bg-green-500/20 text-green-400",
  red: "bg-red-500/20 text-red-400",
};

export function StatsCard({ title, value, icon: Icon, trend, color }: StatsCardProps) {
  const isPositive = trend.startsWith("+");

  return (
    <div className={`rounded-lg border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-gray-400">{title}</p>
        <div className={`p-2 rounded-lg ${iconColorClasses[color]}`}>
          <Icon size={20} />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <p className="text-2xl font-bold text-gray-100">{value}</p>
        <span
          className={`text-sm ${
            isPositive ? "text-green-400" : "text-red-400"
          }`}
        >
          {trend}
        </span>
      </div>
    </div>
  );
}
