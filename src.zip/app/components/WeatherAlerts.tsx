import { Cloud, CloudRain, Sun, Wind, Droplets } from "lucide-react";
import { useEffect, useState } from "react";

interface WeatherData {
  condition: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
  forecast: string;
  icon: any;
}

const weatherConditions = [
  {
    condition: "Sunny",
    temperature: 28,
    humidity: 45,
    windSpeed: 12,
    forecast: "Optimal solar production expected",
    icon: Sun,
  },
  {
    condition: "Partly Cloudy",
    temperature: 26,
    humidity: 55,
    windSpeed: 15,
    forecast: "Reduced output by 20-30%",
    icon: Cloud,
  },
  {
    condition: "Cloudy",
    temperature: 24,
    humidity: 65,
    windSpeed: 18,
    forecast: "Reduced output by 40-50%",
    icon: Cloud,
  },
];

export function WeatherAlerts() {
  const [weather, setWeather] = useState<WeatherData>(weatherConditions[0]);

  useEffect(() => {
    const interval = setInterval(() => {
      const newWeather = weatherConditions[Math.floor(Math.random() * weatherConditions.length)];
      setWeather(newWeather);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const WeatherIcon = weather.icon;

  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
      <h3 className="text-lg font-semibold text-gray-100 mb-4">Weather Conditions</h3>

      <div className="flex items-center gap-4 mb-6">
        <div className="p-4 bg-yellow-500/10 rounded-full">
          <WeatherIcon className="text-yellow-400" size={32} />
        </div>
        <div>
          <p className="text-2xl font-bold text-gray-100">{weather.temperature}°C</p>
          <p className="text-gray-400">{weather.condition}</p>
        </div>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-gray-400">
            <Droplets size={16} />
            <span className="text-sm">Humidity</span>
          </div>
          <span className="text-gray-100 font-semibold">{weather.humidity}%</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-gray-400">
            <Wind size={16} />
            <span className="text-sm">Wind Speed</span>
          </div>
          <span className="text-gray-100 font-semibold">{weather.windSpeed} km/h</span>
        </div>
      </div>

      <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
        <p className="text-sm text-blue-400 flex items-center gap-2">
          <CloudRain size={16} />
          {weather.forecast}
        </p>
      </div>
    </div>
  );
}
