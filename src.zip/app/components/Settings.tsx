import { Bell, Shield, Database, Wifi, Save } from "lucide-react";
import { useState } from "react";

export function Settings() {
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    faults: true,
    weather: false,
  });

  const [dataRetention, setDataRetention] = useState("90");
  const [updateInterval, setUpdateInterval] = useState("2");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Settings</h2>
        <p className="text-gray-400">Configure your dashboard preferences</p>
      </div>

      {/* Notification Settings */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-blue-500/20 rounded-lg">
            <Bell className="text-blue-400" size={20} />
          </div>
          <h3 className="text-xl font-semibold text-gray-100">Notifications</h3>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-100 font-medium">Email Notifications</p>
              <p className="text-sm text-gray-400">Receive alerts via email</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.email}
                onChange={(e) =>
                  setNotifications({ ...notifications, email: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-100 font-medium">Push Notifications</p>
              <p className="text-sm text-gray-400">Get real-time push alerts</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.push}
                onChange={(e) =>
                  setNotifications({ ...notifications, push: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-100 font-medium">Fault Alerts</p>
              <p className="text-sm text-gray-400">Critical system fault notifications</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.faults}
                onChange={(e) =>
                  setNotifications({ ...notifications, faults: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-100 font-medium">Weather Alerts</p>
              <p className="text-sm text-gray-400">Weather condition notifications</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.weather}
                onChange={(e) =>
                  setNotifications({ ...notifications, weather: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Data Settings */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-green-500/20 rounded-lg">
            <Database className="text-green-400" size={20} />
          </div>
          <h3 className="text-xl font-semibold text-gray-100">Data Management</h3>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-gray-100 font-medium mb-2 block">
              Data Retention Period
            </label>
            <select
              value={dataRetention}
              onChange={(e) => setDataRetention(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-gray-100 focus:outline-none focus:border-yellow-500"
            >
              <option value="30">30 days</option>
              <option value="90">90 days</option>
              <option value="180">180 days</option>
              <option value="365">1 year</option>
            </select>
            <p className="text-sm text-gray-400 mt-1">Historical data storage duration</p>
          </div>

          <div>
            <label className="text-gray-100 font-medium mb-2 block">
              Update Interval (seconds)
            </label>
            <select
              value={updateInterval}
              onChange={(e) => setUpdateInterval(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-gray-100 focus:outline-none focus:border-yellow-500"
            >
              <option value="1">1 second</option>
              <option value="2">2 seconds</option>
              <option value="5">5 seconds</option>
              <option value="10">10 seconds</option>
            </select>
            <p className="text-sm text-gray-400 mt-1">How often to refresh live data</p>
          </div>
        </div>
      </div>

      {/* System Settings */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-purple-500/20 rounded-lg">
            <Wifi className="text-purple-400" size={20} />
          </div>
          <h3 className="text-xl font-semibold text-gray-100">System Information</h3>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between py-2 border-b border-gray-800">
            <span className="text-gray-400">System Version</span>
            <span className="text-gray-100 font-medium">v2.4.0</span>
          </div>
          <div className="flex justify-between py-2 border-b border-gray-800">
            <span className="text-gray-400">Last Update</span>
            <span className="text-gray-100 font-medium">Feb 15, 2026</span>
          </div>
          <div className="flex justify-between py-2 border-b border-gray-800">
            <span className="text-gray-400">Connection Status</span>
            <span className="text-green-400 font-medium">● Connected</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-gray-400">Data Source</span>
            <span className="text-gray-100 font-medium">Local Network</span>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <button className="w-full bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-semibold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition-colors">
        <Save size={20} />
        Save Settings
      </button>
    </div>
  );
}
