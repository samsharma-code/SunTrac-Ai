import { AlertTriangle, AlertCircle, Info, CheckCircle } from "lucide-react";
import { useEffect, useState } from "react";

interface Alert {
  id: string;
  type: "error" | "warning" | "info" | "success";
  message: string;
  timestamp: string;
}

const alertIcons = {
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info,
  success: CheckCircle,
};

const alertColors = {
  error: "bg-red-500/10 border-red-500/30 text-red-400",
  warning: "bg-yellow-500/10 border-yellow-500/30 text-yellow-400",
  info: "bg-blue-500/10 border-blue-500/30 text-blue-400",
  success: "bg-green-500/10 border-green-500/30 text-green-400",
};

export function FaultAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "1",
      type: "warning",
      message: "Panel 3 efficiency decreased by 5%",
      timestamp: "2 min ago",
    },
    {
      id: "2",
      type: "info",
      message: "System maintenance scheduled for tomorrow",
      timestamp: "1 hour ago",
    },
    {
      id: "3",
      type: "success",
      message: "All inverters operating normally",
      timestamp: "3 hours ago",
    },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomAlerts: Alert[] = [
        {
          id: Date.now().toString(),
          type: "warning",
          message: "Temperature spike detected in Panel 2",
          timestamp: "Just now",
        },
        {
          id: Date.now().toString(),
          type: "info",
          message: "Cloud coverage reducing output by 15%",
          timestamp: "Just now",
        },
        {
          id: Date.now().toString(),
          type: "success",
          message: "Battery charging efficiency optimal",
          timestamp: "Just now",
        },
      ];

      if (Math.random() > 0.7) {
        const newAlert = randomAlerts[Math.floor(Math.random() * randomAlerts.length)];
        setAlerts((prev) => [newAlert, ...prev.slice(0, 4)]);
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-100">System Alerts</h3>
        <span className="px-3 py-1 bg-gray-800 rounded-full text-xs text-gray-400">
          {alerts.length} Active
        </span>
      </div>

      <div className="space-y-3">
        {alerts.map((alert) => {
          const Icon = alertIcons[alert.type];
          return (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border ${alertColors[alert.type]} flex items-start gap-3`}
            >
              <Icon size={20} className="mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-100">{alert.message}</p>
                <p className="text-xs text-gray-500 mt-1">{alert.timestamp}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
