import { Battery, BatteryCharging } from "lucide-react";
import { useEffect, useState } from "react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

export function BatteryHealth() {
  const [batteryLevel, setBatteryLevel] = useState(87);
  const [isCharging, setIsCharging] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setBatteryLevel((prev) => {
        const change = Math.random() > 0.5 ? 1 : -1;
        const newLevel = Math.max(75, Math.min(100, prev + change * 0.5));
        setIsCharging(newLevel < 95);
        return newLevel;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const healthStatus = batteryLevel > 85 ? "Excellent" : batteryLevel > 70 ? "Good" : "Fair";
  const healthColor = batteryLevel > 85 ? "#22c55e" : batteryLevel > 70 ? "#eab308" : "#ef4444";

  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-100">Battery Health</h3>
        {isCharging ? (
          <BatteryCharging className="text-green-400" size={24} />
        ) : (
          <Battery className="text-gray-400" size={24} />
        )}
      </div>

      <div className="flex items-center justify-center gap-8">
        <div style={{ width: 140, height: 140 }}>
          <CircularProgressbar
            value={batteryLevel}
            text={`${batteryLevel.toFixed(0)}%`}
            styles={buildStyles({
              pathColor: healthColor,
              textColor: "#f3f4f6",
              trailColor: "#374151",
              textSize: "20px",
            })}
          />
        </div>

        <div className="space-y-4">
          <div>
            <p className="text-sm text-gray-400">Status</p>
            <p className="text-lg font-semibold" style={{ color: healthColor }}>
              {healthStatus}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Capacity</p>
            <p className="text-lg font-semibold text-gray-100">10.5 kWh</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Cycle Count</p>
            <p className="text-lg font-semibold text-gray-100">342</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Est. Remaining</p>
            <p className="text-lg font-semibold text-gray-100">
              {isCharging ? "Charging..." : "6.5 hrs"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
