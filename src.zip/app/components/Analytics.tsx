import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";
import { TrendingUp, Zap, DollarSign, Calendar } from "lucide-react";

const energyProductionData = [
  { month: "Jan", production: 320, consumption: 280 },
  { month: "Feb", production: 380, consumption: 300 },
  { month: "Mar", production: 420, consumption: 310 },
  { month: "Apr", production: 480, consumption: 290 },
  { month: "May", production: 520, consumption: 305 },
  { month: "Jun", production: 580, consumption: 320 },
];

const dailyProductionData = [
  { hour: "6am", power: 50 },
  { hour: "8am", power: 250 },
  { hour: "10am", power: 420 },
  { hour: "12pm", power: 580 },
  { hour: "2pm", power: 520 },
  { hour: "4pm", power: 380 },
  { hour: "6pm", power: 150 },
  { hour: "8pm", power: 0 },
];

export function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Analytics</h2>
        <p className="text-gray-400">Energy production and consumption insights</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <TrendingUp className="text-green-400" size={20} />
            </div>
            <p className="text-sm text-gray-400">Total Production</p>
          </div>
          <p className="text-2xl font-bold text-gray-100">2,700 kWh</p>
          <p className="text-xs text-green-400 mt-1">+12.5% vs last month</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Zap className="text-blue-400" size={20} />
            </div>
            <p className="text-sm text-gray-400">Avg. Daily Output</p>
          </div>
          <p className="text-2xl font-bold text-gray-100">90 kWh</p>
          <p className="text-xs text-blue-400 mt-1">Peak: 120 kWh</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-yellow-500/20 rounded-lg">
              <DollarSign className="text-yellow-400" size={20} />
            </div>
            <p className="text-sm text-gray-400">Energy Savings</p>
          </div>
          <p className="text-2xl font-bold text-gray-100">$324</p>
          <p className="text-xs text-yellow-400 mt-1">This month</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Calendar className="text-purple-400" size={20} />
            </div>
            <p className="text-sm text-gray-400">System Uptime</p>
          </div>
          <p className="text-2xl font-bold text-gray-100">99.8%</p>
          <p className="text-xs text-purple-400 mt-1">Last 30 days</p>
        </div>
      </div>

      {/* Charts */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-100">Monthly Production vs Consumption</h3>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={energyProductionData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="month" stroke="#9ca3af" tick={{ fill: "#9ca3af" }} />
            <YAxis stroke="#9ca3af" tick={{ fill: "#9ca3af" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px",
                color: "#f3f4f6",
              }}
            />
            <Legend wrapperStyle={{ color: "#9ca3af" }} />
            <Bar dataKey="production" fill="#22c55e" name="Production (kWh)" />
            <Bar dataKey="consumption" fill="#3b82f6" name="Consumption (kWh)" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-100">Today's Power Production</h3>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={dailyProductionData}>
            <defs>
              <linearGradient id="colorPower" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#eab308" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="hour" stroke="#9ca3af" tick={{ fill: "#9ca3af" }} />
            <YAxis stroke="#9ca3af" tick={{ fill: "#9ca3af" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px",
                color: "#f3f4f6",
              }}
            />
            <Area
              type="monotone"
              dataKey="power"
              stroke="#eab308"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorPower)"
              name="Power (W)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
