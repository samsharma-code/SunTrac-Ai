import { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
  ComposedChart,
} from "recharts";
import { Calendar, TrendingUp, TrendingDown, ArrowRight } from "lucide-react";

// Generate historical data for the past 30 days
function generateHistoricalData() {
  const data = [];
  const today = new Date();
  
  for (let i = 29; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    
    // Simulate realistic solar production with variations
    const baseProduction = 85;
    const seasonalVariation = Math.sin((i / 30) * Math.PI) * 10;
    const randomVariation = (Math.random() - 0.5) * 20;
    const weatherImpact = Math.random() > 0.7 ? -20 : 0; // 30% chance of bad weather
    
    const production = Math.max(
      40,
      baseProduction + seasonalVariation + randomVariation + weatherImpact
    );
    
    data.push({
      date: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      fullDate: date.toLocaleDateString(),
      production: parseFloat(production.toFixed(1)),
      efficiency: parseFloat((75 + Math.random() * 20).toFixed(1)),
      peakPower: parseFloat((production * 1.3 + Math.random() * 50).toFixed(0)),
    });
  }
  
  return data;
}

// Generate hourly data for comparison
function generateHourlyComparison() {
  const hours = [];
  const today = [];
  const yesterday = [];
  const weekAgo = [];
  
  for (let i = 6; i <= 20; i++) {
    const hour = i > 12 ? `${i - 12}pm` : i === 12 ? "12pm" : `${i}am`;
    hours.push(hour);
    
    // Bell curve for solar production during the day
    const peakHour = 13;
    const hourFactor = Math.exp(-Math.pow(i - peakHour, 2) / 18);
    
    today.push({
      hour,
      today: parseFloat((hourFactor * 600 * (0.9 + Math.random() * 0.2)).toFixed(0)),
      yesterday: parseFloat((hourFactor * 600 * (0.85 + Math.random() * 0.2)).toFixed(0)),
      weekAgo: parseFloat((hourFactor * 600 * (0.8 + Math.random() * 0.25)).toFixed(0)),
    });
  }
  
  return today;
}

// Generate weekly summary
function generateWeeklySummary() {
  const weeks = [];
  const weekNames = ["Week 1", "Week 2", "Week 3", "Week 4"];
  
  for (let i = 0; i < 4; i++) {
    weeks.push({
      week: weekNames[i],
      production: parseFloat((550 + Math.random() * 100).toFixed(1)),
      target: 600,
      efficiency: parseFloat((75 + Math.random() * 15).toFixed(1)),
    });
  }
  
  return weeks;
}

export function Comparison() {
  const [historicalData, setHistoricalData] = useState(generateHistoricalData());
  const [hourlyData, setHourlyData] = useState(generateHourlyComparison());
  const [weeklyData, setWeeklyData] = useState(generateWeeklySummary());
  const [selectedPeriod, setSelectedPeriod] = useState<"daily" | "weekly" | "monthly">("daily");

  // Update today's data in real-time
  useEffect(() => {
    const interval = setInterval(() => {
      setHistoricalData((prev) => {
        const updated = [...prev];
        const lastIndex = updated.length - 1;
        const currentProduction = updated[lastIndex].production;
        
        // Small random variation for today's data
        updated[lastIndex] = {
          ...updated[lastIndex],
          production: parseFloat(
            Math.max(40, currentProduction + (Math.random() - 0.5) * 5).toFixed(1)
          ),
        };
        
        return updated;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Calculate statistics
  const currentProduction = historicalData[historicalData.length - 1].production;
  const yesterdayProduction = historicalData[historicalData.length - 2].production;
  const weekAgoProduction = historicalData[historicalData.length - 8]?.production || 0;
  const monthAverage =
    historicalData.reduce((sum, day) => sum + day.production, 0) / historicalData.length;

  const dailyChange = ((currentProduction - yesterdayProduction) / yesterdayProduction) * 100;
  const weeklyChange = ((currentProduction - weekAgoProduction) / weekAgoProduction) * 100;
  const vsAverage = ((currentProduction - monthAverage) / monthAverage) * 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold mb-2">Performance Comparison</h2>
        <p className="text-gray-400">Compare current output with historical data</p>
      </div>

      {/* Period Selector */}
      <div className="flex gap-2">
        <button
          onClick={() => setSelectedPeriod("daily")}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedPeriod === "daily"
              ? "bg-yellow-500 text-gray-900"
              : "bg-gray-800 text-gray-400 hover:bg-gray-700"
          }`}
        >
          Daily
        </button>
        <button
          onClick={() => setSelectedPeriod("weekly")}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedPeriod === "weekly"
              ? "bg-yellow-500 text-gray-900"
              : "bg-gray-800 text-gray-400 hover:bg-gray-700"
          }`}
        >
          Weekly
        </button>
        <button
          onClick={() => setSelectedPeriod("monthly")}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedPeriod === "monthly"
              ? "bg-yellow-500 text-gray-900"
              : "bg-gray-800 text-gray-400 hover:bg-gray-700"
          }`}
        >
          Monthly
        </button>
      </div>

      {/* Comparison Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-400">Today's Output</p>
            <Calendar className="text-blue-400" size={20} />
          </div>
          <p className="text-2xl font-bold text-gray-100">{currentProduction.toFixed(1)} kWh</p>
          <p className="text-xs text-gray-500 mt-1">
            {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric" })}
          </p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-400">vs Yesterday</p>
            {dailyChange >= 0 ? (
              <TrendingUp className="text-green-400" size={20} />
            ) : (
              <TrendingDown className="text-red-400" size={20} />
            )}
          </div>
          <p className="text-2xl font-bold text-gray-100">{yesterdayProduction.toFixed(1)} kWh</p>
          <p
            className={`text-xs mt-1 ${dailyChange >= 0 ? "text-green-400" : "text-red-400"}`}
          >
            {dailyChange >= 0 ? "+" : ""}
            {dailyChange.toFixed(1)}% change
          </p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-400">vs Last Week</p>
            {weeklyChange >= 0 ? (
              <TrendingUp className="text-green-400" size={20} />
            ) : (
              <TrendingDown className="text-red-400" size={20} />
            )}
          </div>
          <p className="text-2xl font-bold text-gray-100">{weekAgoProduction.toFixed(1)} kWh</p>
          <p
            className={`text-xs mt-1 ${weeklyChange >= 0 ? "text-green-400" : "text-red-400"}`}
          >
            {weeklyChange >= 0 ? "+" : ""}
            {weeklyChange.toFixed(1)}% change
          </p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-400">vs 30-Day Avg</p>
            {vsAverage >= 0 ? (
              <TrendingUp className="text-green-400" size={20} />
            ) : (
              <TrendingDown className="text-red-400" size={20} />
            )}
          </div>
          <p className="text-2xl font-bold text-gray-100">{monthAverage.toFixed(1)} kWh</p>
          <p className={`text-xs mt-1 ${vsAverage >= 0 ? "text-green-400" : "text-red-400"}`}>
            {vsAverage >= 0 ? "+" : ""}
            {vsAverage.toFixed(1)}% change
          </p>
        </div>
      </div>

      {/* 30-Day Trend */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-100">
          30-Day Production History
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={historicalData}>
            <defs>
              <linearGradient id="colorProduction" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#eab308" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis
              dataKey="date"
              stroke="#9ca3af"
              tick={{ fill: "#9ca3af", fontSize: 12 }}
              interval="preserveStartEnd"
            />
            <YAxis stroke="#9ca3af" tick={{ fill: "#9ca3af", fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px",
                color: "#f3f4f6",
              }}
            />
            <Legend wrapperStyle={{ color: "#9ca3af" }} />
            <Area
              type="monotone"
              dataKey="production"
              stroke="#eab308"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorProduction)"
              name="Production (kWh)"
            />
            <Line
              type="monotone"
              dataKey="efficiency"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={false}
              name="Efficiency (%)"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Hourly Comparison */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-100">
          Hourly Output Comparison
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={hourlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="hour" stroke="#9ca3af" tick={{ fill: "#9ca3af", fontSize: 12 }} />
            <YAxis stroke="#9ca3af" tick={{ fill: "#9ca3af", fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px",
                color: "#f3f4f6",
              }}
            />
            <Legend wrapperStyle={{ color: "#9ca3af" }} />
            <Line
              type="monotone"
              dataKey="today"
              stroke="#22c55e"
              strokeWidth={2}
              name="Today"
            />
            <Line
              type="monotone"
              dataKey="yesterday"
              stroke="#3b82f6"
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Yesterday"
            />
            <Line
              type="monotone"
              dataKey="weekAgo"
              stroke="#9ca3af"
              strokeWidth={2}
              strokeDasharray="3 3"
              name="1 Week Ago"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Weekly Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-100">
            Weekly Production Summary
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="week" stroke="#9ca3af" tick={{ fill: "#9ca3af" }} />
              <YAxis stroke="#9ca3af" tick={{ fill: "#9ca3af" }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1f2937",
                  border: "1px solid #374151",
                  borderRadius: "8px",
                  color: "#f3f4f6",
                }}
              />
              <Legend wrapperStyle={{ color: "#9ca3af" }} />
              <Bar dataKey="production" fill="#eab308" name="Actual (kWh)" />
              <Bar dataKey="target" fill="#374151" name="Target (kWh)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-100">Performance Insights</h3>
          <div className="space-y-4">
            <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
              <div className="flex items-start gap-3">
                <TrendingUp className="text-green-400 mt-1" size={20} />
                <div>
                  <p className="text-sm font-semibold text-green-400">Strong Performance</p>
                  <p className="text-xs text-gray-400 mt-1">
                    Production is {Math.abs(vsAverage).toFixed(1)}% above monthly average
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <div className="flex items-start gap-3">
                <Calendar className="text-blue-400 mt-1" size={20} />
                <div>
                  <p className="text-sm font-semibold text-blue-400">Best Day This Month</p>
                  <p className="text-xs text-gray-400 mt-1">
                    {
                      historicalData.reduce((max, day) =>
                        day.production > max.production ? day : max
                      ).fullDate
                    }{" "}
                    with{" "}
                    {historicalData
                      .reduce((max, day) => (day.production > max.production ? day : max))
                      .production.toFixed(1)}{" "}
                    kWh
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
              <div className="flex items-start gap-3">
                <ArrowRight className="text-yellow-400 mt-1" size={20} />
                <div>
                  <p className="text-sm font-semibold text-yellow-400">Monthly Projection</p>
                  <p className="text-xs text-gray-400 mt-1">
                    Estimated total: {(monthAverage * 30).toFixed(0)} kWh for this month
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Historical Data Table */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-100">Recent Production Records</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">Date</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">
                  Production (kWh)
                </th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">
                  Efficiency (%)
                </th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">
                  Peak Power (W)
                </th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">
                  vs Avg
                </th>
              </tr>
            </thead>
            <tbody>
              {historicalData.slice(-7).reverse().map((day, index) => {
                const variance = ((day.production - monthAverage) / monthAverage) * 100;
                return (
                  <tr
                    key={index}
                    className="border-b border-gray-800 hover:bg-gray-800/50 transition-colors"
                  >
                    <td className="py-3 px-4 text-sm text-gray-100">{day.fullDate}</td>
                    <td className="py-3 px-4 text-sm text-gray-100">{day.production}</td>
                    <td className="py-3 px-4 text-sm text-gray-100">{day.efficiency}</td>
                    <td className="py-3 px-4 text-sm text-gray-100">{day.peakPower}</td>
                    <td
                      className={`py-3 px-4 text-sm ${
                        variance >= 0 ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {variance >= 0 ? "+" : ""}
                      {variance.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
